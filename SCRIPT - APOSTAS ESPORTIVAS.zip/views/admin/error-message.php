<?php
//don't allow direct access via url
if ( ! defined('ABSPATH') ) {
    exit();
}
?>
<div class="error">
    
    <p>
        
        <?php echo $error_message; ?>
        
    </p>
    
</div>
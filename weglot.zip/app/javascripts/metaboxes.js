import "./find-polyfill";
import "./filter-polyfill";
import InitUrlTranslate from "./metaboxes/url-translate";

InitUrlTranslate();
